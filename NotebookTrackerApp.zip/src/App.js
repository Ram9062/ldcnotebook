// Paste your complete App.js code here (already shown in previous messages)
